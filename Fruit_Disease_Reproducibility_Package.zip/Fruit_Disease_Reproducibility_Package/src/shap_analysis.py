# SHAP utility scaffold. Confirm the explainer, masking strategy, background selection,
# paired modality handling and output semantics before using values in a manuscript.
import argparse,torch,numpy as np,shap
from pathlib import Path
from torch.utils.data import DataLoader
from common import Dataset3M,device_for
from model import MultimodalTransformer
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/config.yaml"); ap.add_argument("--checkpoint",default="outputs/best_model.pt"); ap.add_argument("--modality",choices=["satellite","climate"],required=True); ap.add_argument("--background",type=int,default=10); ap.add_argument("--explain",type=int,default=10); a=ap.parse_args()
    ck=torch.load(a.checkpoint,map_location="cpu"); cfg=ck["config"]; d=cfg["data"]; m=cfg["model"]; dev=device_for(cfg["runtime"]["device"])
    tr=Dataset3M(cfg,"train"); te=Dataset3M(cfg,"test")
    net=MultimodalTransformer(len(d["satellite_columns"]),len(d["climate_columns"]),d["num_classes"],m["embedding_dim"],m["transformer_layers"],m["attention_heads"],m["dropout"],m["feedforward_dim"])
    net.load_state_dict(ck["model_state"]); net.to(dev).eval()
    bg=[tr[i] for i in range(min(a.background,len(tr)))]; ex=[te[i] for i in range(min(a.explain,len(te)))]
    imgs=torch.stack([v["image"] for v in ex]).to(dev)
    sat=torch.stack([v["sat"] for v in ex]).to(dev); clim=torch.stack([v["clim"] for v in ex]).to(dev)
    background=torch.stack([v["sat"] if a.modality=="satellite" else v["clim"] for v in bg]).to(dev)
    values=sat if a.modality=="satellite" else clim
    def predict(z):
        # This wrapper expects one perturbed row per paired explained record.
        if z.shape[0]!=imgs.shape[0]:
            raise ValueError("Perturbation batch does not match paired explanation records; adapt masker/batching before use.")
        with torch.no_grad():
            out=net(imgs,z,clim) if a.modality=="satellite" else net(imgs,sat,z)
            return out.softmax(1).cpu().numpy()
    explainer=shap.KernelExplainer(predict,background.cpu().numpy())
    vals=explainer.shap_values(values.cpu().numpy(),nsamples="auto")
    out=Path(cfg["runtime"]["output_dir"]); out.mkdir(parents=True,exist_ok=True)
    np.save(out/f"shap_{a.modality}.npy",np.asarray(vals,dtype=object),allow_pickle=True)
    print("Saved SHAP output for reconstructed model. Validate method before reporting.")
if __name__=="__main__": main()
