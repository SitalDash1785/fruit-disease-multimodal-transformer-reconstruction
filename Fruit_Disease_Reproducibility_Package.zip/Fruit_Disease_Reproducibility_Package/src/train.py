import argparse,json
from pathlib import Path
import numpy as np, torch
from torch import nn
from torch.utils.data import DataLoader
from sklearn.utils.class_weight import compute_class_weight
from common import load_config,seed_everything,device_for,Dataset3M
from model import MultimodalTransformer

def epoch(model,loader,opt,lossfn,dev,training):
    model.train(training); total=correct=0; loss_sum=0.
    for b in loader:
        x=b["image"].to(dev); s=b["sat"].to(dev); c=b["clim"].to(dev); y=b["label"].to(dev)
        if training: opt.zero_grad()
        with torch.set_grad_enabled(training):
            z=model(x,s,c); loss=lossfn(z,y)
            if training: loss.backward(); opt.step()
        loss_sum+=loss.item()*len(y); correct+=(z.argmax(1)==y).sum().item(); total+=len(y)
    return loss_sum/total,correct/total

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/config.yaml"); args=ap.parse_args()
    cfg=load_config(args.config); seed_everything(cfg["seed"]); d=cfg["data"]; m=cfg["model"]; t=cfg["training"]
    dev=device_for(cfg["runtime"]["device"])
    tr=Dataset3M(cfg,"train"); va=Dataset3M(cfg,"val")
    tl=DataLoader(tr,batch_size=d["batch_size"],shuffle=True,num_workers=d["num_workers"])
    vl=DataLoader(va,batch_size=d["batch_size"],shuffle=False,num_workers=d["num_workers"])
    labels=tr.df.label.to_numpy(); classes=np.unique(labels)
    weights=np.ones(d["num_classes"],dtype=np.float32)
    if t["class_weighted_loss"]:
        for k,w in zip(classes,compute_class_weight("balanced",classes=classes,y=labels)): weights[int(k)]=w
    model=MultimodalTransformer(len(d["satellite_columns"]),len(d["climate_columns"]),d["num_classes"],
        m["embedding_dim"],m["transformer_layers"],m["attention_heads"],m["dropout"],m["feedforward_dim"]).to(dev)
    lossfn=nn.CrossEntropyLoss(weight=torch.tensor(weights,device=dev))
    opt=torch.optim.AdamW(model.parameters(),lr=t["learning_rate"],weight_decay=t["weight_decay"])
    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=t["scheduler_t_max"],eta_min=t["min_learning_rate"])
    out=Path(cfg["runtime"]["output_dir"]); out.mkdir(parents=True,exist_ok=True)
    best=float("inf"); wait=0; hist=[]
    for e in range(t["epochs"]):
        a,b=epoch(model,tl,opt,lossfn,dev,True); c,dv=epoch(model,vl,opt,lossfn,dev,False); sched.step()
        hist.append(dict(epoch=e+1,train_loss=a,train_accuracy=b,val_loss=c,val_accuracy=dv,lr=opt.param_groups[0]["lr"]))
        print(f"epoch {e+1}: train_loss={a:.4f} val_loss={c:.4f} val_acc={dv:.4f}")
        if c<best:
            best=c; wait=0; torch.save({"model_state":model.state_dict(),"config":cfg},out/"best_model.pt")
        else:
            wait+=1
            if wait>=t["early_stopping_patience"]: break
    (out/"training_history.json").write_text(json.dumps(hist,indent=2))
if __name__=="__main__": main()
