# Grad-CAM for the reconstructed ResNet-18 image branch.
# Verify this target layer and explainability design before scientific interpretation.
import argparse,torch,numpy as np,matplotlib.pyplot as plt
from pathlib import Path
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from common import Dataset3M,device_for
from model import MultimodalTransformer
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/config.yaml"); ap.add_argument("--checkpoint",default="outputs/best_model.pt"); ap.add_argument("--sample-index",type=int,default=0); a=ap.parse_args()
    ck=torch.load(a.checkpoint,map_location="cpu"); cfg=ck["config"]; d=cfg["data"]; m=cfg["model"]; dev=device_for(cfg["runtime"]["device"])
    ds=Dataset3M(cfg,"test"); item=ds[a.sample_index]
    net=MultimodalTransformer(len(d["satellite_columns"]),len(d["climate_columns"]),d["num_classes"],m["embedding_dim"],m["transformer_layers"],m["attention_heads"],m["dropout"],m["feedforward_dim"])
    net.load_state_dict(ck["model_state"]); net.to(dev).eval()
    class Wrap(torch.nn.Module):
        def __init__(self,base,sat,clim): super().__init__(); self.base=base; self.sat=sat; self.clim=clim
        def forward(self,img): return self.base(img,self.sat.expand(img.size(0),-1),self.clim.expand(img.size(0),-1))
    wrapped=Wrap(net,item["sat"].unsqueeze(0).to(dev),item["clim"].unsqueeze(0).to(dev))
    cam=GradCAM(model=wrapped,target_layers=[net.image_encoder.layer4[-1]])
    gray=cam(input_tensor=item["image"].unsqueeze(0).to(dev))[0]
    x=item["image"].permute(1,2,0).numpy(); rgb=np.clip(x*np.array([.229,.224,.225])+np.array([.485,.456,.406]),0,1)
    overlay=show_cam_on_image(rgb,gray,use_rgb=True)
    out=Path(cfg["runtime"]["output_dir"]); out.mkdir(parents=True,exist_ok=True); plt.imsave(out/f"gradcam_{item['sample_id']}.png",overlay)
    print("Saved reconstructed-model Grad-CAM.")
if __name__=="__main__": main()
