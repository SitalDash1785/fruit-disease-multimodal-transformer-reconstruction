import torch
from torch import nn
from torchvision.models import resnet18

class MultimodalTransformer(nn.Module):
    """Reconstruction default: ResNet-18 + three projected modality tokens + CLS token."""
    def __init__(self,sat_dim,clim_dim,n_classes,dim=512,layers=6,heads=8,dropout=.2,ff_dim=1024):
        super().__init__()
        if dim%heads: raise ValueError("Embedding dimension must be divisible by attention heads")
        backbone=resnet18(weights=None)  # Reconstruction choice; not asserted as original backbone.
        image_dim=backbone.fc.in_features; backbone.fc=nn.Identity()
        self.image_encoder=backbone
        self.image_proj=nn.Linear(image_dim,dim)
        self.sat_proj=nn.Linear(sat_dim,dim); self.clim_proj=nn.Linear(clim_dim,dim)
        self.modality=nn.Parameter(torch.zeros(1,3,dim))
        self.position=nn.Parameter(torch.zeros(1,4,dim))
        self.cls=nn.Parameter(torch.randn(1,1,dim)*.02)
        layer=nn.TransformerEncoderLayer(dim,heads,ff_dim,dropout,activation="gelu",batch_first=True)
        self.encoder=nn.TransformerEncoder(layer,layers)
        self.head=nn.Linear(dim,n_classes)
    def forward(self,image,sat,clim):
        a=self.image_proj(self.image_encoder(image))
        b=self.sat_proj(sat); c=self.clim_proj(clim)
        x=torch.stack([a,b,c],dim=1)+self.modality+self.position[:,1:,:]
        cls=self.cls.expand(x.size(0),-1,-1)+self.position[:,:1,:]
        return self.head(self.encoder(torch.cat([cls,x],dim=1))[:,0])
