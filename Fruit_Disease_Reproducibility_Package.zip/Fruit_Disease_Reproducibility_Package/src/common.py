from pathlib import Path
import random, numpy as np, pandas as pd, torch, yaml
from PIL import Image
from torch.utils.data import Dataset

def load_config(path):
    with open(path, encoding="utf-8") as f: return yaml.safe_load(f)

def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def device_for(value):
    return torch.device("cuda" if value == "auto" and torch.cuda.is_available()
                        else "cpu" if value == "auto" else value)

def image_tensor(path, size):
    im = Image.open(path).convert("RGB").resize((size,size))
    a = np.asarray(im,dtype=np.float32)/255.
    a = (a-np.array([.485,.456,.406]))/np.array([.229,.224,.225])
    return torch.from_numpy(a.transpose(2,0,1).copy())

class Dataset3M(Dataset):
    def __init__(self,cfg,split):
        d=cfg["data"]; self.df=pd.read_csv(d["metadata_csv"])
        req={"sample_id","district_id","image_path","label","split"}
        if req-set(self.df): raise ValueError(f"Missing columns: {req-set(self.df)}")
        self.df=self.df[self.df.split==split].reset_index(drop=True)
        if self.df.empty: raise ValueError(f"No rows for split {split}")
        self.sat=d["satellite_columns"]; self.clim=d["climate_columns"]; self.size=d["image_size"]
        missing=set(self.sat+self.clim)-set(self.df.columns)
        if missing: raise ValueError(f"Missing feature columns: {missing}")
        if self.df[self.sat+self.clim].isna().any().any(): raise ValueError("Missing feature values; preprocess explicitly.")
    def __len__(self): return len(self.df)
    def __getitem__(self,i):
        r=self.df.iloc[i]; p=Path(str(r.image_path))
        if not p.is_absolute(): p=Path.cwd()/p
        if not p.exists(): raise FileNotFoundError(p)
        return {"image":image_tensor(p,self.size),
                "sat":torch.tensor(r[self.sat].to_numpy(dtype=np.float32)),
                "clim":torch.tensor(r[self.clim].to_numpy(dtype=np.float32)),
                "label":torch.tensor(int(r.label),dtype=torch.long),
                "sample_id":str(r.sample_id)}
