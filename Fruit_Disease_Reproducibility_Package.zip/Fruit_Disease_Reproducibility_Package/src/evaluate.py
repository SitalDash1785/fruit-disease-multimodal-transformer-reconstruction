import argparse
from pathlib import Path
import pandas as pd, torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score,precision_recall_fscore_support,confusion_matrix
from common import device_for,Dataset3M
from model import MultimodalTransformer

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/config.yaml"); ap.add_argument("--checkpoint",default="outputs/best_model.pt"); args=ap.parse_args()
    ck=torch.load(args.checkpoint,map_location="cpu"); cfg=ck["config"]; d=cfg["data"]; m=cfg["model"]; dev=device_for(cfg["runtime"]["device"])
    ds=Dataset3M(cfg,"test"); loader=DataLoader(ds,batch_size=d["batch_size"],shuffle=False)
    model=MultimodalTransformer(len(d["satellite_columns"]),len(d["climate_columns"]),d["num_classes"],m["embedding_dim"],m["transformer_layers"],m["attention_heads"],m["dropout"],m["feedforward_dim"])
    model.load_state_dict(ck["model_state"]); model.to(dev).eval(); y=[]; p=[]; ids=[]; probs=[]
    with torch.no_grad():
        for b in loader:
            q=model(b["image"].to(dev),b["sat"].to(dev),b["clim"].to(dev)).softmax(1).cpu()
            probs.extend(q.tolist()); p.extend(q.argmax(1).tolist()); y.extend(b["label"].tolist()); ids.extend(b["sample_id"])
    pr,re,f1,_=precision_recall_fscore_support(y,p,average="weighted",zero_division=0)
    out=Path(cfg["runtime"]["output_dir"]); out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame({"sample_id":ids,"true_label":y,"predicted_label":p,**{f"prob_{i}":[v[i] for v in probs] for i in range(d["num_classes"])}}).to_csv(out/"test_predictions.csv",index=False)
    import json
    (out/"evaluation_metrics.json").write_text(json.dumps({"accuracy":accuracy_score(y,p),"precision_weighted":pr,"recall_weighted":re,"f1_weighted":f1,"confusion_matrix":confusion_matrix(y,p).tolist()},indent=2))
    print("Saved outputs. These are reconstruction results, not original manuscript results.")
if __name__=="__main__": main()
