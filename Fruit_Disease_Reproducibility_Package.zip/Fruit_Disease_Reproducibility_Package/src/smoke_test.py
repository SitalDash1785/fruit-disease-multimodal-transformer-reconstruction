import torch
from model import MultimodalTransformer
if __name__=="__main__":
    net=MultimodalTransformer(4,3,5)
    out=net(torch.randn(2,3,224,224),torch.randn(2,4),torch.randn(2,3))
    assert out.shape==(2,5)
    torch.nn.CrossEntropyLoss()(out,torch.tensor([0,1])).backward()
    print("Synthetic smoke test passed; this does not validate manuscript results.")
